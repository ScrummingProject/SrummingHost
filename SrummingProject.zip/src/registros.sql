-- Inserción de registros en la tabla de Usuarios
INSERT INTO Usuarios (usuario_id, nombre, email, tipo_usuario, contrasena)
VALUES
(1, 'Admin1', 'admin1@example.com', 'administrador', 'contrasena123'),
(2, 'Usuario1', 'usuario1@example.com', 'normal', 'password123'),
(3, 'Usuario2', 'usuario2@example.com', 'normal', 'qwerty123'),
(4, 'Admin2', 'admin2@example.com', 'administrador', 'adminpass'),
(5, 'Usuario3', 'usuario3@example.com', 'normal', 'securepass');

-- Inserción de registros en la tabla de Proyectos
INSERT INTO Proyectos (proyecto_id, nombre_proyecto, descripcion, fecha_inicio, fecha_fin, estado)
VALUES
(1, 'Proyecto1', 'Descripción del Proyecto 1', '2023-01-01', '2023-02-28', 'activo'),
(2, 'Proyecto2', 'Descripción del Proyecto 2', '2023-03-01', '2023-04-30', 'activo'),
(3, 'Proyecto3', 'Descripción del Proyecto 3', '2023-05-01', '2023-06-30', 'inactivo'),
(4, 'Proyecto4', 'Descripción del Proyecto 4', '2023-07-01', '2023-08-31', 'activo'),
(5, 'Proyecto5', 'Descripción del Proyecto 5', '2023-09-01', '2023-10-31', 'inactivo');

-- Inserción de registros en la tabla de Actividades
INSERT INTO Actividades (actividad_id, nombre_actividad, descripcion, fecha_inicio, fecha_fin, estado, proyecto_id)
VALUES
(1, 'Actividad1', 'Descripción de la Actividad 1', '2023-01-02', '2023-01-15', 'completada', 1),
(2, 'Actividad2', 'Descripción de la Actividad 2', '2023-03-05', '2023-03-20', 'en_proceso', 2),
(3, 'Actividad3', 'Descripción de la Actividad 3', '2023-05-10', '2023-05-25', 'pendiente', 3),
(4, 'Actividad4', 'Descripción de la Actividad 4', '2023-07-15', '2023-08-01', 'en_proceso', 4),
(5, 'Actividad5', 'Descripción de la Actividad 5', '2023-09-20', '2023-10-05', 'pendiente', 5);

-- Inserción de registros en la tabla de Actividades por Sprint
INSERT INTO ActividadesSprint (actividades_sprint_id, actividad_id, sprint_numero)
VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 1),
(4, 4, 3),
(5, 5, 2);

-- Inserción de registros en la tabla de Tablero Kanban Personal
INSERT INTO TableroKanbanPersonal (tablero_personal_id, usuario_id, actividad_id, estado)
VALUES
(1, 1, 1, 'completada'),
(2, 2, 2, 'en_proceso'),
(3, 3, 3, 'pendiente'),
(4, 4, 4, 'en_proceso'),
(5, 5, 5, 'pendiente');

-- Inserción de registros en la tabla de Tablero Kanban Grupal
INSERT INTO TableroKanbanGrupal (tablero_grupal_id, proyecto_id, actividad_id, estado)
VALUES
(1, 1, 1, 'pendiente'),
(2, 2, 2, 'completada'),
(3, 3, 3, 'en_proceso'),
(4, 4, 4, 'pendiente'),
(5, 5, 5, 'en_proceso');
