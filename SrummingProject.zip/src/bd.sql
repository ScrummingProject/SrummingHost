-- Tabla de Usuarios
CREATE TABLE Usuarios (
    usuario_id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    tipo_usuario ENUM('administrador', 'normal') NOT NULL,
    contrasena VARCHAR(100) NOT NULL
);

-- Tabla de Proyectos
CREATE TABLE Proyectos (
    proyecto_id INT PRIMARY KEY,
    nombre_proyecto VARCHAR(100) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE,
    fecha_fin DATE,
    estado ENUM('activo', 'inactivo') NOT NULL
);

-- Tabla de Actividades
CREATE TABLE Actividades (
    actividad_id INT PRIMARY KEY,
    nombre_actividad VARCHAR(100) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE,
    fecha_fin DATE,
    estado ENUM('pendiente', 'en_proceso', 'completada') NOT NULL,
    proyecto_id INT,
    FOREIGN KEY (proyecto_id) REFERENCES Proyectos(proyecto_id)
);

-- Tabla de Actividades por Sprint
CREATE TABLE ActividadesSprint (
    actividades_sprint_id INT PRIMARY KEY,
    actividad_id INT,
    sprint_numero INT,
    FOREIGN KEY (actividad_id) REFERENCES Actividades(actividad_id)
);

-- Tabla de Tablero Kanban Personal
CREATE TABLE TableroKanbanPersonal (
    tablero_personal_id INT PRIMARY KEY,
    usuario_id INT,
    actividad_id INT,
    estado ENUM('pendiente', 'en_proceso', 'completada') NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES Usuarios(usuario_id),
    FOREIGN KEY (actividad_id) REFERENCES Actividades(actividad_id)
);

-- Tabla de Tablero Kanban Grupal
CREATE TABLE TableroKanbanGrupal (
    tablero_grupal_id INT PRIMARY KEY,
    proyecto_id INT,
    actividad_id INT,
    estado ENUM('pendiente', 'en_proceso', 'completada') NOT NULL,
    FOREIGN KEY (proyecto_id) REFERENCES Proyectos(proyecto_id),
    FOREIGN KEY (actividad_id) REFERENCES Actividades(actividad_id)
);
