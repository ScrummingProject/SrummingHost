from flask import Flask, render_template, request, redirect
from config import conexion
from sqlalchemy import create_engine
import pandas as pd

app = Flask(name)

@app.route("/")
def inicio():
    return render_template("login.html")

@app.route("/cuenta")
def inicios():
    return render_template("cuenta.html")

@app.route("/iniciar", methods=["POST", "GET"])
def sacardatos():
    if "enviar" in request.form:
        print("Diste clic en enviar")
        nombre = request.form["usuario"]
        contraseña = request.form["contraseña"]
        rol = request.form["rol"]

        if rol == "Administrador":

            # Aquí traigo los datos de la base de datos
            conexiones = conexion()
            cursor = conexiones.cursor(dictionary=True)
            query = 'SELECT login.ROL, login.USUARIO, login.CONTRASEÑA FROM login WHERE login.USUARIO = %s'
            cursor.execute(query, (nombre,))
            result = cursor.fetchone()

            if result:
                print("Encontró coincidencias")
                rolbase = result['ROL']
                usuariobase = result['USUARIO']
                contraseñabase = result['CONTRASEÑA']
                
                print("Datos de la base:", rolbase, usuariobase, contraseñabase)
                print("Datos del formulario:", rol, nombre, contraseña)

                # Verifica la contraseña
                if contraseña == contraseñabase:
                    print("Accedimos")
                    return redirect("/menu")
                else:
                    print("Contraseña incorrecta")
        elif rol == "Usuario":

            # Aquí traigo los datos de la base de datos
            conexiones = conexion()
            cursor = conexiones.cursor(dictionary=True)
            query = 'SELECT  cuentas.usuario, cuentas.contraseña FROM cuentas WHERE cuentas.usuario = %s'
            cursor.execute(query, (nombre,))
            result = cursor.fetchone()

            if result:
                print("Encontró coincidencias")
                
                usuariobase = result['usuario']
                contraseñabase = result['contraseña']
                
                print("Datos de la base:",  usuariobase, contraseñabase)
                print("Datos del formulario:",  nombre, contraseña)

                # Verifica la contraseña
                if contraseña == contraseñabase:
                    print("Accedimos")
                    return "<h2>Bienvenido usuario"
                else:
                    print("Contraseña incorrecta")
            
           

        cursor.close()
        conexiones.close()

    if "registrar" in request.form:
        print("voy a cuenta")
        return redirect("/cuenta")

    return "<p>Credenciales incorrectas</p>"

@app.route("/cuenta", methods=["POST", "GET"])
def registrar():
    if "reg" in request.form:
        nombre = request.form["nombre"]
        primer = request.form["primerapellido"]
        segundo = request.form["segundoapellido"]
        usuario = request.form["usuario"]
        contraseña = request.form["contrasena"]

        conexiones = conexion()
        cursor = conexiones.cursor(dictionary=True)

        # Utiliza comillas simples para los valores y comillas dobles para los nombres de columnas con espacios
        query = 'INSERT INTO cuentas (Nombre, Primer Apellido, Segundo Apellido, usuario, contraseña) VALUES (%s, %s, %s, %s, %s)'
        values = (nombre, primer, segundo, usuario, contraseña)

        cursor.execute(query, values)
        conexiones.commit()

        cursor.close()
        return "<p>Registro exitoso </p>"

@app.route("/menu", methods=["POcST", "GET"])
def registrarr():
    return render_template("menuindex.html")

engine = create_engine('mysql+pymysql://root:@localhost:3306/administracion')
