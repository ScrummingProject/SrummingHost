import sqlite3

conexion = sqlite3.connect('proyecto.db')

cursor = conexion.cursor()
cursor.execute('''CREATE TABLE Proyectos (
    proyecto_id INTEGER PRIMARY KEY,
    nombre_proyecto TEXT NOT NULL,
    descripcion TEXT,
    fecha_inicio TEXT,
    fecha_fin TEXT,
    estado BOOLEAN NOT NULL
)''')

conexion.commit()
conexion.close()