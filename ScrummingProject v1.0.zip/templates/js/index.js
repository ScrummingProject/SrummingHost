

document.getElementById("btn__registrarse").addEventListener("click", mostrarFormularioRegistro);
document.getElementById("btn__iniciar-sesion").addEventListener("click", mostrarFormularioInicioSesion);

var contenedor_login_register = document.querySelector(".contenedor__login-register");
var formulario_login = document.querySelector(".formulario__login");
var formulario_register = document.querySelector(".formulario__register");
var caja_trasera_login = document.querySelector(".caja__trasera-login");
var caja_trasera_register = document.querySelector(".caja__trasera-register");

function mostrarFormularioRegistro() {
    console.log("Mostrar formulario de registro");

    formulario_register.style.display = "block";
    contenedor_login_register.style.left = "410px";
    formulario_login.style.display = "none";
    caja_trasera_register.style.opacity = "0";
    caja_trasera_login.style.opacity = "1";
}

function mostrarFormularioInicioSesion() {
    console.log("Mostrar formulario de inicio de sesión");

    formulario_login.style.display = "block";
    contenedor_login_register.style.left = "10px";
    formulario_register.style.display = "none";
    caja_trasera_register.style.opacity = "1";
    caja_trasera_login.style.opacity = "0";
}
