const tablaActividades = document.getElementById("tabla-actividades");
const newSprintButton = document.querySelector(".new-sprint");

// Variable para rastrear el sprint actual
let currentSprint;

// Variable para rastrear la fila de actividad actual
let currentRow;

// Función para crear un nuevo sprint
function crearNuevoSprint() {
    const nombreSprint = prompt("Ingrese el nombre del sprint:");
    if (nombreSprint) {
        const filaSprint = document.createElement("tr");
        filaSprint.innerHTML = `
            <td colspan="6" class="sprint-title">${nombreSprint}</td>
            
            <td>
                <button class="add-row-to-sprint">Agregar Actividad</button>
                <button class="edit-sprint">Editar Sprint</button>
                <button class="delete-sprint">Eliminar Sprint</button>
            </td>
            <td><i class="fa-solid fa-check" style="color: green;"></i></td>
        `;
        tablaActividades.appendChild(filaSprint);
        currentSprint = filaSprint;
    }
}

// Evento para crear un nuevo sprint al hacer clic en "Nuevo Sprint"
newSprintButton.addEventListener("click", crearNuevoSprint);

// Función para editar el nombre del sprint
function editarSprint() {
    if (currentSprint) {
        const nuevoNombreSprint = prompt("Editar el nombre del sprint:", currentSprint.querySelector(".sprint-title").textContent);
        if (nuevoNombreSprint) {
            currentSprint.querySelector(".sprint-title").textContent = nuevoNombreSprint;
        }
    }
}

// Función para eliminar el sprint actual
function eliminarSprint() {
    if (currentSprint) {
        tablaActividades.removeChild(currentSprint);
        currentSprint = undefined;
    }
}

// Evento para editar o eliminar el sprint
tablaActividades.addEventListener("click", function (e) {
    if (e.target.classList.contains("edit-sprint")) {
        editarSprint();
    } else if (e.target.classList.contains("delete-sprint")) {
        eliminarSprint();
    } else if (e.target.classList.contains("add-row-to-sprint")) {
        agregarActividad();
    }
});

// Función para agregar una actividad al sprint actual
function agregarActividad() {
    if (!currentSprint) {
        alert("Cree un sprint primero.");
        return;
    }

    const fila = document.createElement("tr");
    fila.innerHTML = `
        <td><input type="text" class="actividad" value="" /></td>
        <td><input type="text" class="duracion" value="" /></td>
        <td><input type="date" class="fecha-inicio" value="" /></td>
        <td><input type="date" class "fecha-termino" value="" /></td>
        <td><input type="text" class="responsable" value="" /></td>
        <td>
            <button class="save">Guardar</button>
            <button class="edit-row">Editar</button>
            <button class="delete-row">Eliminar</button>
        </td>
    `;
    tablaActividades.appendChild(fila);
}

// Evento para agregar una actividad al hacer clic en un botón
document.querySelector(".add-row").addEventListener("click", function () {
    agregarActividad();
});

// Función para eliminar una fila
function eliminarFila(fila) {
    fila.remove();
}

// Función para editar una fila
function editarFila(fila) {
    currentRow = fila;
    const inputs = fila.querySelectorAll("input");
    inputs.forEach((input) => {
        input.readOnly = false;
    });
}

// Evento para eliminar o editar una fila al hacer clic en los botones correspondientes
tablaActividades.addEventListener("click", function (e) {
    if (e.target.classList.contains("delete-row")) {
        eliminarFila(e.target.closest("tr"));
    } else if (e.target.classList.contains("edit-row")) {
        editarFila(e.target.closest("tr"));
    } else if (e.target.classList.contains("save")) {
        guardarFila(e.target.closest("tr"));
    }
});

// Función para guardar una fila
function guardarFila(fila) {
    const inputs = fila.querySelectorAll("input");
    inputs.forEach((input) => {
        input.readOnly = true;
    });
    currentRow = null;
}
