// Supongamos que esta es una representación de tus datos de ejemplo
const datos = [
    {
        actividad: "Actividad 1",
        duracion: "2 horas",
        fechaInicio: "2023-10-29",
        fechaTermino: "2023-10-31",
        responsable: "Usuario 1",
    },
    {
        actividad: "Actividad 2",
        duracion: "3 horas",
        fechaInicio: "2023-11-01",
        fechaTermino: "2023-11-03",
        responsable: "Usuario 2",
    },
    // Agrega más datos aquí
];

// Obtén la tabla de actividades y responsables
const tablaActividadesResponsables = document.getElementById("tabla-actividades-responsables");

// Llena la tabla de actividades y responsables
datos.forEach((fila) => {
    const filaTabla = document.createElement("tr");
    filaTabla.innerHTML = `
        <td>${fila.actividad}</td>
        <td>${fila.responsable}</td>
    `;
    tablaActividadesResponsables.appendChild(filaTabla);
});
