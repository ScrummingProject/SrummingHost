from flask import Flask, render_template, request, redirect, url_for
from sqlalchemy import create_engine
from sqlalchemy import create_engine, text  # Asegúrate de agregar 'text' aquí
from sqlalchemy.orm import sessionmaker

import pandas as pd

app = Flask(__name__)

engine = create_engine('mysql+pymysql://root:@localhost:3306/scrum')
Session = sessionmaker(bind=engine)

datos_usuarios = []


# Ruta para logearse
@app.route('/', methods=['GET', 'POST'])
def login():
    return render_template('Index.html')

@app.route("/iniciar", methods=["POST", "GET"])
def sacardatos():
    if request.method == 'POST':

        email = request.form['nombre1']
        contrasena = request.form['contrasena']

        # Crear una sesión
        session = Session()

        try:
            # Consulta para verificar si las credenciales son válidas
            query = text(f"SELECT * FROM Usuarios WHERE email='{email}' AND contrasena='{contrasena}'")
            resultado = session.execute(query).fetchone()

            if resultado:
                # Las credenciales son válidas, redirige a una página de éxito
                return redirect(url_for('menuprincipal'))
            else:
                # Las credenciales son incorrectas, redirige a una página de error
                return redirect(url_for('iniciar'))
        finally:
            # Cerrar la sesión
            session.close()


# Ruta para registrar
@app.route('/registro', methods=['POST'])
def reg():
    if request.method == 'POST':
        
        fullname = request.form['fullname']
        email = request.form['email']
        user = 'normal'
        password = request.form['password']

        datos_usuarios.append({'nombre': fullname, 'email': email, 'tipo_usuario': user, 'contrasena': password})
        df = pd.DataFrame(datos_usuarios)
        print(df)
        nombre_de_la_tabla = 'Usuarios'
        df.to_sql(nombre_de_la_tabla, con=engine, if_exists='append', index=False)
        return render_template('Index.html')


#muestra el menu inicio    
@app.route('/menuinicio')
def menu():
    return render_template ('menu_principal.html')

#muestra el menu principal
@app.route('/menuprincipal')
def menuprincipal():
    return render_template ('menuindex.html')

#Ruta para el dashboard
@app.route('/dashboard')
def function():
    return render_template ('dashboard.html')





# Ruta para mostrar la tabla de usuarios administradores
@app.route('/mostrar_usuarios_administradores')
def mostrar_usuarios_administradores():
    # Consulta SQL para obtener datos de la tabla
    query = "SELECT * FROM Usuarios"
    
    # Obtener los resultados y crear un DataFrame
    df = pd.read_sql_query(query, engine)
    
    # Renderizar el HTML con la tabla
    return render_template('tabla_usuarios.html', tables=[df.to_html(classes='data', index=False)], titles=df.columns.values)

if __name__ == '__main__':
    app.run(debug=True)